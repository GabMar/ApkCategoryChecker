#!/bin/sh

java -jar ApkCategoryChecker.jar -d -csv